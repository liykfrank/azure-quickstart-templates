﻿configuration CreateADPDC
{
   param
   (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

    Import-DscResource -ModuleName xActiveDirectory, xStorage, xNetworking, PSDesiredStateConfiguration, xPendingReboot
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)
    
    $webProxyName = "webproxy"
    $webProxyIP = "10.0.10.200"

    Node localhost
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        } 

        WindowsFeature DNS
        {
            Ensure = "Present"
            Name = "DNS"
        }

        Script EnableDNSDiags
        {
      	    SetScript = {
                Set-DnsServerDiagnostics -All $true
                Write-Verbose -Verbose "Enabling DNS client diagnostics"
            }
            GetScript =  { @{} }
            TestScript = { $false }
            DependsOn = "[WindowsFeature]DNS"
        }

        WindowsFeature DnsTools
        {
            Ensure = "Present"
            Name = "RSAT-DNS-Server"
            DependsOn = "[WindowsFeature]DNS"
        }

        xDnsServerAddress DnsServerAddress
        {
            Address        = '127.0.0.1'
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
            DependsOn = "[WindowsFeature]DNS"
        }

        xWaitforDisk Disk2
        {
            DiskNumber = 2
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }

        xDisk ADDataDisk {
            DiskNumber = 2
            DriveLetter = "F"
            DependsOn = "[xWaitForDisk]Disk2"
        }

        WindowsFeature ADDSInstall
        {
            Ensure = "Present"
            Name = "AD-Domain-Services"
            DependsOn="[WindowsFeature]DNS"
        }

        WindowsFeature ADDSTools
        {
            Ensure = "Present"
            Name = "RSAT-ADDS-Tools"
            DependsOn = "[WindowsFeature]ADDSInstall"
        }

        WindowsFeature ADAdminCenter
        {
            Ensure = "Present"
            Name = "RSAT-AD-AdminCenter"
            DependsOn = "[WindowsFeature]ADDSTools"
        }

        xADDomain FirstDS
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = "F:\NTDS"
            LogPath = "F:\NTDS"
            SysvolPath = "F:\SYSVOL"
            DependsOn = @("[WindowsFeature]ADDSInstall", "[xDisk]ADDataDisk")
        }

        xPendingReboot RebootAfterPromotion{
            Name = "RebootAfterPromotion"
            SkipCcmClientSDK = $true 
            DependsOn = "[xADDomain]FirstDS"
        }
        
        Script SetDNSDynamicUpdate
        { 
            GetScript = { @{ Result = "Updated $using:DomainName DynamicUpdate to NonsecureAndSecure " } }
            TestScript = {
                Write-Verbose "Test DNS Server Zone $using:DomainName DynamicUpdate setting"
                $dnsSetting = Get-DnsServerZone -Name $using:DomainName -ErrorAction SilentlyContinue
                if($dnsSetting -and ($dnsSetting.DynamicUpdate -eq "NonsecureAndSecure")) {
                    return $true
                }
                return $false
            }
            SetScript = {
                Write-Verbose "Set DNS Server Primary Zone $using:DomainName to NonsecureAndSecure "
                Set-DnsServerPrimaryZone -Name $using:DomainName -DynamicUpdate "NonsecureAndSecure"
            }
            DependsOn = "[xPendingReboot]RebootAfterPromotion" 
        }

        Script AddDNSRecord
        { 
            GetScript = { @{ Result = "$using:webProxyName $using:webProxyIP" } }
            TestScript = {
                Write-Verbose "Test A Record $using:webProxyName $using:webProxyIP to DNS Zone $using:DomainName"
                $record = Get-DnsServerResourceRecord -ZoneName $using:DomainName -Name $using:webProxyName -RRType A -ErrorAction SilentlyContinue
                if($record) {
                    return $true
                }
                return $false
            }
            SetScript = {
                Write-Verbose "Add New A Record $using:webProxyName $using:webProxyIP to DNS Zone $using:DomainName"
                Add-DnsServerResourceRecordA -ZoneName $using:DomainName -Name $using:webProxyName -IPv4Address $using:webProxyIP
            }
            DependsOn = "[xPendingReboot]RebootAfterPromotion" 
        }

   }
}