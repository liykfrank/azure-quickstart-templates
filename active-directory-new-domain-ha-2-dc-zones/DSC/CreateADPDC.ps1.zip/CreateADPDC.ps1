﻿configuration CreateADPDC 
{ 
   param 
   ( 
        [String]$DomainName = "testad.poc202006test",
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName ActiveDirectoryDSC, xNetworking, xPendingReboot

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    $webProxyName = "webproxy"
    $webProxyIP = "10.0.10.10"

    Node localhost
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        } 

        Registry SetRegisteredOwner 
        { 
            Ensure = 'Present' 
            Force = $True 
            Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion' 
            ValueName = 'RegisteredOwner' 
            ValueType = 'String' 
            ValueData = $Node.RegisteredOwner 
        }

        WindowsFeatureSet DnsAddsFeatures
        { 
            Ensure = "Present" 
            Name = @("DNS", "RSAT-DNS-Server", "AD-Domain-Services", "RSAT-AD-PowerShell", "RSAT-ADDS-Tools")
        }

        xDnsServerAddress DnsServerAddress 
        { 
            Address        = '127.0.0.1' 
            InterfaceAlias = 'Ethernet*'
            AddressFamily  = 'IPv4'
            DependsOn = "[WindowsFeatureSet]DnsAddsFeatures"
        }

        ADDomain FirstDS
        {
            DomainName                    = $DomainName
            Credential                    = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DependsOn = "[WindowsFeatureSet]DnsAddsFeatures"
        }

        xPendingReboot Reboot1
        { 
            Name = "RebootServer"
            SkipCcmClientSDK = $true 
        }


        Script SetDNSDynamicUpdate
        { 
            GetScript = { @{ Result = "Updated $using:DomainName DynamicUpdate to NonsecureAndSecure " } }
            TestScript = {
                Write-Verbose "Test DNS Server Zone $using:DomainName DynamicUpdate setting"
                $dnsSetting = Get-DnsServerZone -Name $using:DomainName -ErrorAction SilentlyContinue
                if($dnsSetting -and ($dnsSetting.DynamicUpdate -eq "NonsecureAndSecure")) {
                    return $true
                }
                return $false
            }
            SetScript = {
                Write-Verbose "Set DNS Server Primary Zone $using:DomainName to NonsecureAndSecure "
                Set-DnsServerPrimaryZone -Name $using:DomainName -DynamicUpdate "NonsecureAndSecure"
            }
            DependsOn = "[xPendingReboot]Reboot1" 
        }

        Script AddDNSRecord
        { 
            GetScript = { @{ Result = "$using:webProxyName $using:webProxyIP" } }
            TestScript = {
                Write-Verbose "Test A Record $using:webProxyName $using:webProxyIP to DNS Zone $using:DomainName"
                $record = Get-DnsServerResourceRecord -ZoneName $using:DomainName -Name $using:webProxyName -RRType A -ErrorAction SilentlyContinue
                if($record) {
                    return $true
                }
                return $false
            }
            SetScript = {
                Write-Verbose "Add New A Record $using:webProxyName $using:webProxyIP to DNS Zone $using:DomainName"
                Add-DnsServerResourceRecordA -ZoneName $using:DomainName -Name $using:webProxyName -IPv4Address $using:webProxyIP
            }
            DependsOn = "[xPendingReboot]Reboot1" 
        }
   }
}